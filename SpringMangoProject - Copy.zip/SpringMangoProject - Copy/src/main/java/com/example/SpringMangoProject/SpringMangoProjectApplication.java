package com.example.SpringMangoProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringMangoProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringMangoProjectApplication.class, args);
	}

}
