package com.example.SpringMangoProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringMangoProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
